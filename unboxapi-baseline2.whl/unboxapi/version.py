# Define the SDK version here so that both the setup.py and the interal package can have access to this value.
# See https://stackoverflow.com/questions/2058802
__version__ = "0.1.0"
